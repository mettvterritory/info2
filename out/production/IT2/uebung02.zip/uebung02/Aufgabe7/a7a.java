package uebung02.Aufgabe7;
import blatt02.Hobby;
import java.util.zip.DataFormatException;

/**
 * <Aufgabe 7 a>
 * <p>
 * Copyright (c) $today.year
 *
 * @author: Samuel Luft
 */
public class a7a {
	public static  void main (String args[]){
		try{
			Hobby lesen = new Hobby("Lesen");
			lesen.setPriority(lesen.getPriority()-1);
		}catch(DataFormatException ex){
			System.err.println("Hobby operation has failed due to: " + (ex.getMessage()));
		}
	}
}

